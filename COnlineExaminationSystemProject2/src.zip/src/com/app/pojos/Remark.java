package com.app.pojos;

public enum Remark {
	PASS,FAIL
}
