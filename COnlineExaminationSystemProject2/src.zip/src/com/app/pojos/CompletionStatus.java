package com.app.pojos;

public enum CompletionStatus {

	COMPLETED,PENDING
}
