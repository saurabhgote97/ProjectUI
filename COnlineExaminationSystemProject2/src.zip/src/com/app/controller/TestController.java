package com.app.controller;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dao.ILogin;
import com.app.dao.IStudentDao;
import com.app.pojos.QuestionDatabase;
import com.app.pojos.Student;
import com.app.service.ICommon;

@CrossOrigin
@RestController
@RequestMapping("/test")
public class TestController {

	@Autowired
	private IStudentDao studao;
	
	
	@GetMapping("/listQuestion")
	private ResponseEntity<?> getList()
	{
		Set<QuestionDatabase> questions = studao.getQuestionList();
		if(questions != null)
			return new ResponseEntity<Set<QuestionDatabase>>(questions,HttpStatus.OK);
		return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
	}
}