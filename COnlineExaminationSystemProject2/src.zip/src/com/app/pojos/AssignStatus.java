package com.app.pojos;

public enum AssignStatus {
	ASSIGNED,NOT_ASSIGNED
}
